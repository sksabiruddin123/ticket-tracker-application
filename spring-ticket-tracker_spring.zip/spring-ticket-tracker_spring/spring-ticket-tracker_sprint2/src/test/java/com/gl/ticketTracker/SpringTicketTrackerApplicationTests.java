package com.gl.ticketTracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringTicketTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
